/**
 * Calculadora Oficial / Blue con variación local (Opción 1)
 * API ArgentinaDatos
 */

const API = "https://api.argentinadatos.com/v1/cotizaciones/dolares/";

const $montoUsd = document.getElementById("montoUsd");
const $btn = document.getElementById("btnCalcular");
const $total = document.getElementById("total");
const $cotizacion = document.getElementById("cotizacion");
const $varUp = document.getElementById("varUp");
const $varDown = document.getElementById("varDown");
const $tipoActual = document.getElementById("tipoActual");
const $mdOficial = document.getElementById("mdOficial");
const $mdBlue = document.getElementById("mdBlue");

let oficialHoy=null, oficialFecha=null;
let blueHoy=null, blueFecha=null;

const fmtARS = n => n.toLocaleString("es-AR",{style:"currency",currency:"ARS",maximumFractionDigits:0});
const clamp = (v,a,b)=>Math.min(Math.max(v,a),b);

function classForPct(p){const pct=clamp(p,-2,2);if(pct>=1.5)return"var--g7";if(pct>=1.0)return"var--g6";if(pct>=0.5)return"var--g5";if(pct>0)return"var--g4";if(pct===0)return"var--n0";if(pct>-0.5)return"var--r4";if(pct>-1.0")